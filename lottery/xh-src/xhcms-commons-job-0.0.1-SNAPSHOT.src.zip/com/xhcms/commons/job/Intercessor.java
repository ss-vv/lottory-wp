package com.xhcms.commons.job;

public abstract interface Intercessor
{
  public abstract boolean isAllowable();
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.Intercessor
 * JD-Core Version:    0.6.2
 */