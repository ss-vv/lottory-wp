/*    */ package com.xhcms.commons.job;
/*    */ 
/*    */ import com.xhcms.commons.job.impl.UnlimitedIntercessor;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public abstract class Job
/*    */   implements Runnable
/*    */ {
/*  9 */   protected Logger log = LoggerFactory.getLogger(getClass());
/*    */ 
/* 11 */   private Intercessor intercessor = new UnlimitedIntercessor();
/*    */ 
/*    */   public void run()
/*    */   {
/* 15 */     if (this.log.isDebugEnabled()) {
/* 16 */       this.log.debug("start job: " + toString());
/*    */     }
/*    */ 
/* 19 */     if (!this.intercessor.isAllowable()) {
/* 20 */       if (this.log.isDebugEnabled())
/* 21 */         this.log.debug("job is rejected by intercessor.");
/*    */     }
/*    */     else
/*    */       try {
/* 25 */         execute();
/*    */       } catch (Throwable t) {
/* 27 */         warn(this.log, t);
/*    */       }
/*    */   }
/*    */ 
/*    */   protected abstract void execute() throws Exception;
/*    */ 
/*    */   protected void warn(Logger log, Throwable t)
/*    */   {
/* 35 */     if (log.isDebugEnabled())
/* 36 */       log.debug("", t);
/*    */     else
/* 38 */       log.warn(t.getMessage());
/*    */   }
/*    */ 
/*    */   public void setIntercessor(Intercessor intercessor)
/*    */   {
/* 43 */     this.intercessor = intercessor;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.Job
 * JD-Core Version:    0.6.2
 */