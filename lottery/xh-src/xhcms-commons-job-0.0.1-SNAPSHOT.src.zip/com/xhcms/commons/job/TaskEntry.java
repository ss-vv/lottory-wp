/*    */ package com.xhcms.commons.job;
/*    */ 
/*    */ public abstract class TaskEntry extends Task
/*    */ {
/*    */   private Workspace workspace;
/*    */ 
/*    */   public void run()
/*    */   {
/*  9 */     this.workspace.assign(createJob());
/*    */   }
/*    */ 
/*    */   public abstract Job createJob();
/*    */ 
/*    */   public void setWorkspace(Workspace workspace) {
/* 15 */     this.workspace = workspace;
/*    */   }
/*    */ 
/*    */   public Workspace getWorkspace() {
/* 19 */     return this.workspace;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.TaskEntry
 * JD-Core Version:    0.6.2
 */