/*    */ package com.xhcms.commons.job;
/*    */ 
/*    */ import java.util.Timer;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class JobTimer
/*    */ {
/*  9 */   private static final Logger log = LoggerFactory.getLogger(JobTimer.class);
/*    */ 
/* 11 */   private Timer timer = new Timer(true);
/*    */ 
/*    */   public void destroy() {
/* 14 */     this.timer.cancel();
/* 15 */     log.info("timer stopped");
/*    */   }
/*    */ 
/*    */   public void addTask(Task t) {
/* 19 */     if (t.getFirstTime() != null)
/* 20 */       this.timer.schedule(t, t.getFirstTime(), t.getPeriod());
/*    */     else
/* 22 */       this.timer.schedule(t, t.getDelay(), t.getPeriod());
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.JobTimer
 * JD-Core Version:    0.6.2
 */