/*    */ package com.xhcms.commons.job;
/*    */ 
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.LinkedBlockingQueue;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class Workspace
/*    */ {
/* 12 */   private static final Logger log = LoggerFactory.getLogger(Workspace.class);
/*    */ 
/* 14 */   private int coreSize = 1;
/* 15 */   private int maxSize = 1;
/*    */   private String name;
/*    */   private ExecutorService service;
/*    */ 
/*    */   public void assign(Job job)
/*    */   {
/* 20 */     if (log.isDebugEnabled()) {
/* 21 */       log.debug("assign work to workspace: " + this.name);
/*    */     }
/* 23 */     this.service.execute(job);
/*    */   }
/*    */ 
/*    */   public void init() {
/* 27 */     if (this.name == null) {
/* 28 */       this.name = ("Workspace-" + this);
/*    */     }
/* 30 */     if (this.maxSize < this.coreSize) {
/* 31 */       this.maxSize = this.coreSize;
/*    */     }
/*    */ 
/* 34 */     this.service = new ThreadPoolExecutor(this.coreSize, this.maxSize, 0L, TimeUnit.MILLISECONDS, 
/* 35 */       new LinkedBlockingQueue());
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 39 */     log.info("workspace stopping: " + this.name);
/*    */ 
/* 41 */     this.service.shutdown();
/*    */     try {
/* 43 */       this.service.awaitTermination(1L, TimeUnit.MINUTES);
/*    */     } catch (InterruptedException e) {
/* 45 */       e.printStackTrace();
/*    */     }
/*    */ 
/* 48 */     log.info("workspace stopped: " + this.name);
/*    */   }
/*    */ 
/*    */   public void setCoreSize(int coreSize) {
/* 52 */     this.coreSize = coreSize;
/*    */   }
/*    */ 
/*    */   public void setMaxSize(int maxSize) {
/* 56 */     this.maxSize = maxSize;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 60 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.Workspace
 * JD-Core Version:    0.6.2
 */