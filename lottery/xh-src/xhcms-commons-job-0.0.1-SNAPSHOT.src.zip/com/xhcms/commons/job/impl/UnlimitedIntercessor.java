/*   */ package com.xhcms.commons.job.impl;
/*   */ 
/*   */ import com.xhcms.commons.job.Intercessor;
/*   */ 
/*   */ public class UnlimitedIntercessor
/*   */   implements Intercessor
/*   */ {
/*   */   public boolean isAllowable()
/*   */   {
/* 9 */     return true;
/*   */   }
/*   */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.impl.UnlimitedIntercessor
 * JD-Core Version:    0.6.2
 */