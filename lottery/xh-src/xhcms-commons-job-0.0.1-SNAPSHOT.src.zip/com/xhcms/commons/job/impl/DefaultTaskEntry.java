/*    */ package com.xhcms.commons.job.impl;
/*    */ 
/*    */ import com.xhcms.commons.job.Job;
/*    */ import com.xhcms.commons.job.TaskEntry;
/*    */ 
/*    */ public class DefaultTaskEntry extends TaskEntry
/*    */ {
/*    */   private Job job;
/*    */ 
/*    */   public Job createJob()
/*    */   {
/* 12 */     return this.job;
/*    */   }
/*    */ 
/*    */   public void setJob(Job job) {
/* 16 */     this.job = job;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.impl.DefaultTaskEntry
 * JD-Core Version:    0.6.2
 */