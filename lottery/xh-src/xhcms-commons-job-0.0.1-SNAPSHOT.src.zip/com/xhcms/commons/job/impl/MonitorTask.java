/*    */ package com.xhcms.commons.job.impl;
/*    */ 
/*    */ import com.xhcms.commons.job.JobTimer;
/*    */ import com.xhcms.commons.job.Task;
/*    */ import java.io.File;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ public class MonitorTask extends Task
/*    */ {
/*    */   private static final String PID_FILE = "/dev/shm/da";
/*    */   private JobTimer timer;
/*    */ 
/*    */   public void run()
/*    */   {
/* 16 */     File file = new File("/dev/shm/da");
/* 17 */     if (!file.exists()) {
/* 18 */       this.log.info("stopping...");
/* 19 */       destroy();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setTimer(JobTimer timer) {
/* 24 */     this.timer = timer;
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 28 */     this.timer.destroy();
/* 29 */     this.timer = null;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.impl.MonitorTask
 * JD-Core Version:    0.6.2
 */