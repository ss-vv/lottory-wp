/*    */ package com.xhcms.commons.job;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.TimerTask;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public abstract class Task extends TimerTask
/*    */ {
/* 13 */   protected Logger log = LoggerFactory.getLogger(getClass());
/*    */   private String name;
/*    */   private Date firstTime;
/*    */   private long delay;
/*    */   private long period;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 24 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 28 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public Date getFirstTime() {
/* 32 */     return this.firstTime;
/*    */   }
/*    */ 
/*    */   public void setTime(String time) {
/*    */     try {
/* 37 */       this.firstTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(time);
/*    */     } catch (ParseException e) {
/* 39 */       this.firstTime = new Date();
/*    */     }
/*    */   }
/*    */ 
/*    */   public long getDelay() {
/* 44 */     return this.delay;
/*    */   }
/*    */ 
/*    */   public void setDelay(long delay) {
/* 48 */     this.delay = (delay < 0L ? 0L : delay);
/*    */   }
/*    */ 
/*    */   public long getPeriod() {
/* 52 */     return this.period;
/*    */   }
/*    */ 
/*    */   public void setPeriod(long period)
/*    */   {
/* 60 */     this.period = (period * 1000L);
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-job\0.0.1-SNAPSHOT\xhcms-commons-job-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.job.Task
 * JD-Core Version:    0.6.2
 */