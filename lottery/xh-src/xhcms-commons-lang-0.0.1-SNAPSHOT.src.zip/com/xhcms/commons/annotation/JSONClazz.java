package com.xhcms.commons.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface JSONClazz
{
  public abstract Class<?> value();
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.annotation.JSONClazz
 * JD-Core Version:    0.6.2
 */