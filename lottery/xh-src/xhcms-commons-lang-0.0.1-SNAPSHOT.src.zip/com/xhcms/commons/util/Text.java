/*     */ package com.xhcms.commons.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.math.BigInteger;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class Text
/*     */ {
/*  23 */   private static final char[] chs = "0123456789abcdefghijklmnopqrstuv".toCharArray();
/*     */ 
/*  25 */   private static long MINUTE = 60000L;
/*     */ 
/*  27 */   private static long HOUR = 3600000L;
/*     */ 
/*  29 */   private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', 
/*  30 */     '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */ 
/*     */   public static String formatTime(Date date, String pattern)
/*     */   {
/*  42 */     return new SimpleDateFormat(pattern).format(date);
/*     */   }
/*     */ 
/*     */   public static Date parseTime(String value, String pattern)
/*     */   {
/*     */     try
/*     */     {
/*  53 */       return new SimpleDateFormat(pattern).parse(value); } catch (ParseException e) {
/*     */     }
/*  55 */     return null;
/*     */   }
/*     */ 
/*     */   public static String filePath(long key, long seed, int deep)
/*     */   {
/*  70 */     StringBuilder buf = new StringBuilder(32);
/*  71 */     for (int i = 0; i < deep; i++) {
/*  72 */       buf.append(key % seed).append(File.separatorChar);
/*  73 */       key /= seed;
/*     */     }
/*  75 */     return key;
/*     */   }
/*     */ 
/*     */   public static String base32(long value)
/*     */   {
/*  84 */     StringBuilder buf = new StringBuilder(16);
/*  85 */     while (value > 0L) {
/*  86 */       buf.append(chs[((int)(value & 0x1F))]);
/*  87 */       value >>= 5;
/*     */     }
/*  89 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static String base32(long value, long seed)
/*     */   {
/* 100 */     StringBuilder buf = new StringBuilder(32);
/* 101 */     while (value > 0L) {
/* 102 */       buf.append(chs[((int)(value & 0x1F))]);
/* 103 */       value >>= 5;
/*     */     }
/* 105 */     while (seed > 0L) {
/* 106 */       buf.append(chs[((int)(seed & 0x1F))]);
/* 107 */       seed >>= 5;
/*     */     }
/* 109 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static String md5(String value)
/*     */   {
/* 119 */     byte[] code = (byte[])null;
/*     */     try {
/* 121 */       code = MessageDigest.getInstance("md5").digest(value.getBytes());
/*     */     } catch (NoSuchAlgorithmException e) {
/* 123 */       code = value.getBytes();
/*     */     }
/* 125 */     BigInteger bi = new BigInteger(code);
/* 126 */     return bi.abs().toString(32).toUpperCase();
/*     */   }
/*     */ 
/*     */   public static String lapsedTime(Date time)
/*     */   {
/* 142 */     return lapsedTime(Calendar.getInstance(), time);
/*     */   }
/*     */ 
/*     */   public static String lapsedTime(Calendar currentTime, Date time)
/*     */   {
/* 158 */     Calendar c = Calendar.getInstance();
/* 159 */     c.setTime(time);
/*     */ 
/* 161 */     long offset = currentTime.getTimeInMillis() - c.getTimeInMillis();
/*     */ 
/* 163 */     if (offset <= MINUTE)
/* 164 */       return "刚刚";
/* 165 */     if (offset <= HOUR)
/* 166 */       return offset / MINUTE + " 分钟前";
/* 167 */     if (currentTime.get(1) != c.get(1))
/* 168 */       return formatTime(time, "yyyy年M月d日 HH:mm");
/* 169 */     if ((currentTime.get(2) != c.get(2)) || (currentTime.get(5) != c.get(5))) {
/* 170 */       return formatTime(time, "M月d日 HH:mm");
/*     */     }
/* 172 */     return "今天 " + formatTime(time, "HH:mm");
/*     */   }
/*     */ 
/*     */   public static String shortLapsedTime(Calendar currentTime, Date time)
/*     */   {
/* 186 */     Calendar c = Calendar.getInstance();
/* 187 */     c.setTime(time);
/*     */ 
/* 189 */     if (currentTime.get(1) != c.get(1))
/* 190 */       return formatTime(time, "yyyy年");
/* 191 */     if ((currentTime.get(2) != c.get(2)) || (currentTime.get(5) != c.get(5))) {
/* 192 */       return formatTime(time, "M月d日");
/*     */     }
/* 194 */     return "今天" + formatTime(time, "HH:mm");
/*     */   }
/*     */ 
/*     */   public static String byteArrayToHexString(byte[] b)
/*     */   {
/* 203 */     StringBuilder buf = new StringBuilder();
/* 204 */     int n = 0;
/* 205 */     for (int i = 0; i < b.length; i++) {
/* 206 */       n = b[i];
/* 207 */       if (n < 0) {
/* 208 */         n += 256;
/*     */       }
/* 210 */       buf.append(HEX_DIGITS[(n / 16)]).append(HEX_DIGITS[(n % 16)]);
/*     */     }
/* 212 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static String MD5Encode(String src)
/*     */   {
/* 221 */     String result = new String(src);
/*     */     try {
/* 223 */       result = byteArrayToHexString(MessageDigest.getInstance("MD5").digest(result.getBytes()));
/*     */     } catch (Exception localException) {
/*     */     }
/* 226 */     return result;
/*     */   }
/*     */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.util.Text
 * JD-Core Version:    0.6.2
 */