/*    */ package com.xhcms.commons.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Date;
/*    */ import java.util.UUID;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class FileUtil
/*    */ {
/*    */   public static final int SEED = 997;
/* 26 */   private static final Logger log = LoggerFactory.getLogger(FileUtil.class);
/*    */ 
/*    */   public static final String createTempFile(String dir, String suffix)
/*    */   {
/* 38 */     String date = Text.formatTime(new Date(), "yyyyMMdd");
/*    */ 
/* 41 */     File parent = new File(dir, date);
/* 42 */     if (!parent.exists()) {
/* 43 */       parent.mkdirs();
/*    */     }
/*    */ 
/* 48 */     File file = new File(parent, UUID.randomUUID() + suffix);
/* 49 */     boolean created = false;
/*    */     try
/*    */     {
/* 52 */       for (int i = 0; i < 3; i++) {
/* 53 */         if (file.createNewFile()) {
/* 54 */           created = true;
/* 55 */           break;
/*    */         }
/* 57 */         file = new File(parent, UUID.randomUUID() + suffix);
/*    */       }
/*    */     } catch (Exception e) {
/* 60 */       log.warn(e.getMessage());
/*    */     }
/*    */ 
/* 63 */     if (created) {
/* 64 */       return file.getAbsolutePath();
/*    */     }
/*    */ 
/* 67 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.util.FileUtil
 * JD-Core Version:    0.6.2
 */