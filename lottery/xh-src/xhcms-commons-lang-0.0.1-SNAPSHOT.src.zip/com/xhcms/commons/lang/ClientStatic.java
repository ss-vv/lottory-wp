package com.xhcms.commons.lang;

public abstract interface ClientStatic
{
  public static final String VERSION = "__version";
  public static final String TOKEN = "__token";
  public static final String SECURE = "__secure";
  public static final int CODE_OK = 200;
  public static final int CODE_ERROR = 500;
  public static final int CODE_REJEST = 403;
  public static final int CODE_INVALID = 401;
  public static final int CODE_UNSUPPORT_VERSION = 478;
  public static final String POST = "post";
  public static final String GET = "get";
  public static final String RESPONSE_DATA = "data";
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.lang.ClientStatic
 * JD-Core Version:    0.6.2
 */