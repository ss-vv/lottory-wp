/*     */ package com.xhcms.commons.lang;
/*     */ 
/*     */ import com.xhcms.commons.util.Text;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class MD5Authorizer
/*     */   implements Authorizer
/*     */ {
/*  35 */   private static final Logger log = LoggerFactory.getLogger(MD5Authorizer.class);
/*     */   private String seed;
/*  39 */   private HashMap<String, String> values = new HashMap();
/*     */ 
/*  41 */   private HashMap<String, Integer> codeCache = new HashMap();
/*     */ 
/*     */   public int authorize(String token, String secure, String version)
/*     */   {
/*  48 */     if ((token == null) || (secure == null) || (version == null)) {
/*  49 */       return 401;
/*     */     }
/*     */ 
/*  53 */     String param = join(token, secure, version);
/*  54 */     Integer code = lookup(param);
/*  55 */     if (code != null) {
/*  56 */       return code.intValue();
/*     */     }
/*     */ 
/*  60 */     String value = (String)this.values.get(param);
/*  61 */     if (value == null) {
/*  62 */       return 478;
/*     */     }
/*     */ 
/*  66 */     String key = Text.md5(joinKey(param));
/*     */ 
/*  69 */     if (value.equals(key))
/*  70 */       code = Integer.valueOf(200);
/*     */     else {
/*  72 */       code = Integer.valueOf(403);
/*     */     }
/*     */ 
/*  76 */     cache(param, code);
/*     */ 
/*  78 */     return code.intValue();
/*     */   }
/*     */ 
/*     */   public void setTokenValues(List<String> tokenValues)
/*     */   {
/*  88 */     for (String tv : tokenValues) {
/*  89 */       int i = tv.lastIndexOf(':');
/*  90 */       if ((i == -1) || (i == 0) || (i == tv.length() - 1)) {
/*  91 */         log.info("Ignore invalid format for token value: {0}", tv);
/*     */       }
/*     */       else {
/*  94 */         String key = tv.substring(0, i).trim();
/*  95 */         String value = tv.substring(i + 1).trim();
/*     */ 
/*  98 */         if (!Text.md5(joinKey(key)).equals(value)) {
/*  99 */           log.info("Ignore invalid token value: {0}", tv);
/*     */         }
/*     */         else
/*     */         {
/* 104 */           this.values.put(key, value);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setSeed(String seed)
/*     */   {
/* 114 */     this.seed = seed;
/*     */   }
/*     */ 
/*     */   private Integer lookup(String param) {
/* 118 */     return (Integer)this.codeCache.get(param);
/*     */   }
/*     */ 
/*     */   private void cache(String key, Integer value) {
/* 122 */     this.codeCache.put(key, value);
/*     */   }
/*     */ 
/*     */   private String join(String token, String secure, String version) {
/* 126 */     return 64 + 
/* 127 */       token + ':' + 
/* 128 */       secure + ':' + 
/* 129 */       version;
/*     */   }
/*     */ 
/*     */   private String joinKey(String key) {
/* 133 */     return 64 + 
/* 134 */       key + ':' + 
/* 135 */       this.seed;
/*     */   }
/*     */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.lang.MD5Authorizer
 * JD-Core Version:    0.6.2
 */