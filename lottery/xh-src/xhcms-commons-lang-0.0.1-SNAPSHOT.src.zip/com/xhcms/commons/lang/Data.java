/*    */ package com.xhcms.commons.lang;
/*    */ 
/*    */ public class Data
/*    */ {
/*    */   private boolean success;
/*    */   private Object data;
/*    */ 
/*    */   private Data(boolean success, Object data)
/*    */   {
/* 25 */     this.success = success;
/* 26 */     this.data = data;
/*    */   }
/*    */ 
/*    */   public static final Data success(Object data)
/*    */   {
/* 35 */     return new Data(true, data);
/*    */   }
/*    */ 
/*    */   public static final Data failure(Object data)
/*    */   {
/* 44 */     return new Data(false, data);
/*    */   }
/*    */ 
/*    */   public boolean isSuccess()
/*    */   {
/* 52 */     return this.success;
/*    */   }
/*    */ 
/*    */   public void setSuccess(boolean success)
/*    */   {
/* 60 */     this.success = success;
/*    */   }
/*    */ 
/*    */   public Object getData()
/*    */   {
/* 68 */     return this.data;
/*    */   }
/*    */ 
/*    */   public void setData(Object data)
/*    */   {
/* 76 */     this.data = data;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.lang.Data
 * JD-Core Version:    0.6.2
 */