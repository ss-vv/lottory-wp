/*    */ package com.xhcms.commons.lang;
/*    */ 
/*    */ import com.xhcms.exception.XHRuntimeException;
/*    */ 
/*    */ public class Assert
/*    */ {
/*    */   public static void isTrue(boolean expression, int errorCode)
/*    */   {
/* 10 */     if (!expression)
/* 11 */       throw new XHRuntimeException(errorCode);
/*    */   }
/*    */ 
/*    */   public static void isFalse(boolean expression, int errorCode)
/*    */   {
/* 16 */     if (expression)
/* 17 */       throw new XHRuntimeException(errorCode);
/*    */   }
/*    */ 
/*    */   public static void isNull(Object object, int errorCode)
/*    */   {
/* 22 */     isTrue(object == null, errorCode);
/*    */   }
/*    */ 
/*    */   public static void notNull(Object object, int errorCode) {
/* 26 */     isFalse(object == null, errorCode);
/*    */   }
/*    */ 
/*    */   public static void instanceOf(Object object, Class<?> c, int errorCode) {
/* 30 */     isTrue(c.isInstance(object), errorCode);
/*    */   }
/*    */ 
/*    */   public static void notInstanceOf(Object object, Class<?> c, int errorCode) {
/* 34 */     isFalse(c.isInstance(object), errorCode);
/*    */   }
/*    */ 
/*    */   public static void gt(long x, long y, int errorCode) {
/* 38 */     isTrue(x > y, errorCode);
/*    */   }
/*    */ 
/*    */   public static void ge(long x, long y, int errorCode) {
/* 42 */     isTrue(x >= y, errorCode);
/*    */   }
/*    */ 
/*    */   public static void lt(long x, long y, int errorCode) {
/* 46 */     isTrue(x < y, errorCode);
/*    */   }
/*    */ 
/*    */   public static void le(long x, long y, int errorCode) {
/* 50 */     isTrue(x <= y, errorCode);
/*    */   }
/*    */ 
/*    */   public static void eq(long x, long y, int errorCode) {
/* 54 */     isTrue(x == y, errorCode);
/*    */   }
/*    */ 
/*    */   public static void ne(long x, long y, int errorCode) {
/* 58 */     isTrue(x != y, errorCode);
/*    */   }
/*    */ 
/*    */   public static <T> void eq(Comparable<T> x, T y, int errorCode) {
/* 62 */     isTrue(x.compareTo(y) == 0, errorCode);
/*    */   }
/*    */ 
/*    */   public static <T> void ne(Comparable<T> x, T y, int errorCode) {
/* 66 */     isTrue(x.compareTo(y) != 0, errorCode);
/*    */   }
/*    */ 
/*    */   public static <T> void gt(Comparable<T> x, T y, int errorCode) {
/* 70 */     isTrue(x.compareTo(y) == 1, errorCode);
/*    */   }
/*    */ 
/*    */   public static <T> void ge(Comparable<T> x, T y, int errorCode) {
/* 74 */     isTrue(x.compareTo(y) != -1, errorCode);
/*    */   }
/*    */ 
/*    */   public static <T> void lt(Comparable<T> x, T y, int errorCode) {
/* 78 */     isTrue(x.compareTo(y) == -1, errorCode);
/*    */   }
/*    */ 
/*    */   public static <T> void le(Comparable<T> x, T y, int errorCode) {
/* 82 */     isTrue(x.compareTo(y) != 1, errorCode);
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.lang.Assert
 * JD-Core Version:    0.6.2
 */