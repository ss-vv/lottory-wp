/*     */ package com.xhcms.commons.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Paging
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -236455755726836664L;
/*     */   public static final int DEFAULT_MAX_RESULTS = 20;
/*  14 */   private int pageNo = 1;
/*     */ 
/*  17 */   private int maxResults = 20;
/*     */ 
/*  20 */   private List<?> results = Collections.EMPTY_LIST;
/*     */   private int totalCount;
/*  26 */   private boolean count = true;
/*     */ 
/*     */   public Paging()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Paging(int maxResults)
/*     */   {
/*  36 */     setPageNo(1);
/*  37 */     setMaxResults(maxResults);
/*     */   }
/*     */ 
/*     */   public Paging(int pageNo, int maxResults) {
/*  41 */     setPageNo(pageNo);
/*  42 */     setMaxResults(maxResults);
/*     */   }
/*     */ 
/*     */   public int getMaxResults()
/*     */   {
/*  51 */     return this.maxResults;
/*     */   }
/*     */ 
/*     */   public List<?> getResults() {
/*  55 */     return this.results;
/*     */   }
/*     */ 
/*     */   public int getTotalCount() {
/*  59 */     return this.totalCount;
/*     */   }
/*     */ 
/*     */   public int getFirstResult() {
/*  63 */     return (this.pageNo - 1) * this.maxResults;
/*     */   }
/*     */ 
/*     */   public int getPageNo() {
/*  67 */     return this.pageNo;
/*     */   }
/*     */ 
/*     */   public void setPageNo(int pageNo) {
/*  71 */     this.pageNo = (pageNo < 1 ? 1 : pageNo);
/*     */   }
/*     */ 
/*     */   public void setMaxResults(int maxResults) {
/*  75 */     this.maxResults = (maxResults < 0 ? 0 : maxResults);
/*     */   }
/*     */ 
/*     */   public void setResults(List<?> results) {
/*  79 */     this.results = results;
/*     */   }
/*     */ 
/*     */   public void setTotalCount(int totalCount) {
/*  83 */     this.totalCount = totalCount;
/*     */   }
/*     */ 
/*     */   public int getPageCount() {
/*  87 */     if (this.maxResults == 0) {
/*  88 */       return 1;
/*     */     }
/*  90 */     return (int)Math.ceil(this.totalCount * 1.0D / this.maxResults);
/*     */   }
/*     */ 
/*     */   public int getSize()
/*     */   {
/*  99 */     return this.results.size();
/*     */   }
/*     */ 
/*     */   public int getPrevPageNo()
/*     */   {
/* 107 */     return this.pageNo > 1 ? this.pageNo - 1 : 0;
/*     */   }
/*     */ 
/*     */   public int getNextPageNo()
/*     */   {
/* 115 */     int pc = getPageCount();
/* 116 */     return this.pageNo < pc ? this.pageNo + 1 : pc;
/*     */   }
/*     */ 
/*     */   public boolean isCount() {
/* 120 */     return this.count;
/*     */   }
/*     */ 
/*     */   public void setCount(boolean count) {
/* 124 */     this.count = count;
/*     */   }
/*     */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.lang.Paging
 * JD-Core Version:    0.6.2
 */