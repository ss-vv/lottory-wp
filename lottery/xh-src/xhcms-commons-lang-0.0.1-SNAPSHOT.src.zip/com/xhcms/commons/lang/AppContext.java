/*    */ package com.xhcms.commons.lang;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class AppContext
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 287615850964822374L;
/*    */   private String cacheKey;
/*    */   private boolean audited;
/*    */ 
/*    */   public String getCacheKey()
/*    */   {
/* 27 */     return this.cacheKey;
/*    */   }
/*    */ 
/*    */   public void setCacheKey(String cacheKey)
/*    */   {
/* 35 */     this.cacheKey = cacheKey;
/*    */   }
/*    */ 
/*    */   public boolean isAudited()
/*    */   {
/* 43 */     return this.audited;
/*    */   }
/*    */ 
/*    */   public void setAudited(boolean audited)
/*    */   {
/* 51 */     this.audited = audited;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.lang.AppContext
 * JD-Core Version:    0.6.2
 */