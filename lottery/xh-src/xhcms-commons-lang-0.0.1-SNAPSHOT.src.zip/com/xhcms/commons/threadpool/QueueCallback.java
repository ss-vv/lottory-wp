package com.xhcms.commons.threadpool;

public abstract interface QueueCallback
{
  public abstract void onWarning(TaskQueue paramTaskQueue);
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.threadpool.QueueCallback
 * JD-Core Version:    0.6.2
 */