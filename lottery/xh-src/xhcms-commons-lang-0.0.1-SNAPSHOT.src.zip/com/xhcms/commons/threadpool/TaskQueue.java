/*    */ package com.xhcms.commons.threadpool;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class TaskQueue
/*    */ {
/* 17 */   private static Logger logger = LoggerFactory.getLogger(TaskQueue.class);
/*    */   private String name;
/* 19 */   private List<Task> queue = new LinkedList();
/*    */ 
/* 21 */   private Object lock = new Object();
/*    */   private int warnThreshold;
/*    */   private QueueCallback callback;
/*    */ 
/*    */   public TaskQueue(String name, int warnThreshold, QueueCallback callback)
/*    */   {
/* 26 */     if ((name == null) || (name.equals(""))) {
/* 27 */       this.name = "default";
/* 28 */       return;
/*    */     }
/*    */ 
/* 31 */     this.callback = callback;
/* 32 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public int enqueue(Task task, boolean merge) {
/* 36 */     synchronized (this.lock) {
/* 37 */       if ((merge) && 
/* 38 */         (this.queue.contains(task))) {
/* 39 */         logger.info("TaskQueue already contains task : " + task);
/* 40 */         return this.queue.size();
/*    */       }
/*    */ 
/* 43 */       this.queue.add(task);
/*    */ 
/* 46 */       if ((this.warnThreshold > 0) && (this.queue.size() >= this.warnThreshold)) {
/* 47 */         logger.warn("Queue size exceed the max threshold value :" + this.warnThreshold + ", queue size is:" + this.queue.size());
/* 48 */         if ((this.callback != null) && ((this.queue.size() == this.warnThreshold) || ((this.queue.size() > this.warnThreshold) && (this.queue.size() % 1000 == 0)))) {
/* 49 */           this.callback.onWarning(this);
/*    */         }
/*    */       }
/*    */ 
/* 53 */       this.lock.notifyAll();
/*    */ 
/* 55 */       return this.queue.size();
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean remove(Task task) {
/* 60 */     synchronized (this.lock) {
/* 61 */       return this.queue.remove(task);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Task dequeue() throws InterruptedException {
/* 66 */     Task task = null;
/* 67 */     synchronized (this.lock) {
/* 68 */       if (this.queue.size() == 0) {
/*    */         try {
/* 70 */           this.lock.wait();
/*    */         } catch (InterruptedException e) {
/* 72 */           logger.warn(e.getMessage(), e);
/* 73 */           throw e;
/*    */         }
/*    */       }
/* 76 */       if (this.queue.size() > 0) {
/* 77 */         task = (Task)this.queue.remove(0);
/*    */       }
/*    */     }
/* 80 */     return task;
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 84 */     synchronized (this.lock) {
/* 85 */       if (this.queue.size() > 0) {
/* 86 */         logger.info("clear task queue(name=" + this.name + "), it's size is " + this.queue.size());
/* 87 */         this.queue.clear();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int size() {
/* 93 */     synchronized (this.lock) {
/* 94 */       return this.queue.size();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.threadpool.TaskQueue
 * JD-Core Version:    0.6.2
 */