/*     */ package com.xhcms.commons.threadpool;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class ThreadPool
/*     */ {
/*  19 */   private static final Logger logger = LoggerFactory.getLogger(ThreadPool.class);
/*  20 */   private static int instanceCounter = 0;
/*     */   private int maxThreadCount;
/*     */   private int minThreadCount;
/*  25 */   private List<ThreadWorker> pool = new ArrayList();
/*     */   private TaskQueue taskQueue;
/*     */   private TaskConsumer consumer;
/*     */   private String name;
/*     */ 
/*     */   public ThreadPool(String poolName, int minThreadCount, int maxThreadCount, int queueWarnThreshold, QueueCallback queueCallback)
/*     */   {
/*  32 */     this.maxThreadCount = 10;
/*  33 */     this.minThreadCount = 5;
/*     */ 
/*  35 */     synchronized (ThreadPool.class) {
/*  36 */       instanceCounter += 1;
/*  37 */       if ((poolName == null) || (poolName == ""))
/*  38 */         this.name = ("ThreadPool_" + instanceCounter);
/*     */       else {
/*  40 */         this.name = poolName;
/*     */       }
/*     */     }
/*  43 */     this.taskQueue = new TaskQueue(this.name + "_taskqueue", queueWarnThreshold, queueCallback);
/*     */   }
/*     */ 
/*     */   public int getMaxThreadCount() {
/*  47 */     return this.maxThreadCount;
/*     */   }
/*     */ 
/*     */   public int getMinThreadCount() {
/*  51 */     return this.minThreadCount;
/*     */   }
/*     */ 
/*     */   public void start() {
/*  55 */     init();
/*  56 */     this.consumer = new TaskConsumer(null);
/*  57 */     this.consumer.start();
/*     */   }
/*     */ 
/*     */   public void stop() {
/*  61 */     destroy();
/*     */   }
/*     */ 
/*     */   public void addTask(Task task, boolean merge) {
/*  65 */     this.taskQueue.enqueue(task, merge);
/*     */   }
/*     */ 
/*     */   public void removeTask(Task task) {
/*  69 */     this.taskQueue.remove(task);
/*     */   }
/*     */ 
/*     */   private void init() {
/*  73 */     for (int i = 0; i < this.minThreadCount; i++)
/*     */     {
/*  75 */       synchronized (this.pool) {
/*  76 */         ThreadWorker worker = new ThreadWorker();
/*  77 */         this.pool.add(worker);
/*  78 */         worker.start();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void destroy() {
/*  84 */     this.consumer.interrupt();
/*     */ 
/*  86 */     synchronized (this.pool) {
/*  87 */       for (ThreadWorker worker : this.pool) {
/*  88 */         worker.interrupt();
/*     */       }
/*  90 */       this.pool.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getQueueSize() {
/*  95 */     return this.taskQueue.size();
/*     */   }
/*     */ 
/*     */   public int getActiveWorkerCounter() {
/*  99 */     return this.pool.size();
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 103 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 107 */     this.name = name;
/*     */   }
/*     */ 
/*     */   private class TaskConsumer extends Thread {
/* 111 */     private long idleMilliSeconds = 60000L;
/* 112 */     private long sleepMilliSeconds = 2000L;
/*     */ 
/*     */     private TaskConsumer() {
/*     */     }
/* 116 */     public void run() { while (!isInterrupted()) {
/*     */         try {
/* 118 */           Thread.sleep(this.sleepMilliSeconds);
/*     */         } catch (InterruptedException exp) {
/* 120 */           ThreadPool.logger.info("Task consumer thread has been interrupted!");
/* 121 */           break;
/*     */         }
/*     */ 
/* 125 */         synchronized (ThreadPool.this.pool) {
/* 126 */           if ((ThreadPool.this.taskQueue.size() > ThreadPool.this.pool.size()) && (ThreadPool.this.pool.size() < ThreadPool.this.maxThreadCount))
/*     */           {
/* 128 */             ThreadPool.ThreadWorker worker = new ThreadPool.ThreadWorker(ThreadPool.this);
/* 129 */             ThreadPool.this.pool.add(worker);
/* 130 */             worker.start();
/* 131 */           } else if ((ThreadPool.this.taskQueue.size() == 0) && (ThreadPool.this.pool.size() > ThreadPool.this.minThreadCount))
/*     */           {
/* 133 */             List tempPool = new ArrayList();
/* 134 */             tempPool.addAll(ThreadPool.this.pool);
/* 135 */             for (ThreadPool.ThreadWorker worker : tempPool) {
/* 136 */               if ((System.currentTimeMillis() - worker.getLastRunTime() > this.idleMilliSeconds) && 
/* 137 */                 (ThreadPool.this.pool.size() > ThreadPool.this.minThreadCount)) {
/* 138 */                 worker.interrupt();
/* 139 */                 ThreadPool.this.pool.remove(worker);
/*     */               }
/*     */ 
/* 142 */               if (ThreadPool.this.pool.size() <= ThreadPool.this.minThreadCount) {
/*     */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 148 */         if (System.currentTimeMillis() % this.idleMilliSeconds == 0L)
/* 149 */           ThreadPool.logger.debug(ThreadPool.this.getName() + "'s size : " + ThreadPool.this.pool.size() + ", queue's size : " + ThreadPool.this.taskQueue.size());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class ThreadWorker extends Thread
/*     */   {
/* 156 */     private long lastRunTime = 0L;
/*     */ 
/*     */     public ThreadWorker() {
/* 159 */       this.lastRunTime = System.currentTimeMillis();
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 164 */       while (!isInterrupted()) {
/* 165 */         Task task = null;
/*     */         try {
/* 167 */           task = ThreadPool.this.taskQueue.dequeue();
/*     */         } catch (InterruptedException exp) {
/* 169 */           ThreadPool.logger.info(getName() + " thread has been interrupred!");
/* 170 */           break;
/*     */         }
/*     */         try
/*     */         {
/* 174 */           if (task != null)
/* 175 */             task.run();
/*     */         }
/*     */         catch (Throwable exp) {
/* 178 */           ThreadPool.logger.error(exp.getMessage(), exp);
/*     */         }
/*     */ 
/* 181 */         this.lastRunTime = System.currentTimeMillis();
/*     */       }
/*     */     }
/*     */ 
/*     */     public long getLastRunTime() {
/* 186 */       return this.lastRunTime;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.threadpool.ThreadPool
 * JD-Core Version:    0.6.2
 */