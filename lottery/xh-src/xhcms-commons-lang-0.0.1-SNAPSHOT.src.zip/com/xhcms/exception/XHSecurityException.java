/*    */ package com.xhcms.exception;
/*    */ 
/*    */ public class XHSecurityException extends XHRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -3669911555168778902L;
/*    */ 
/*    */   public XHSecurityException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public XHSecurityException(String message)
/*    */   {
/* 20 */     super(message);
/*    */   }
/*    */ 
/*    */   public XHSecurityException(Throwable cause)
/*    */   {
/* 28 */     super(cause);
/*    */   }
/*    */ 
/*    */   public XHSecurityException(String message, Throwable cause)
/*    */   {
/* 36 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.exception.XHSecurityException
 * JD-Core Version:    0.6.2
 */