/*    */ package com.xhcms.exception;
/*    */ 
/*    */ public class XHRuntimeException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -7443213283905815106L;
/*    */   private int code;
/*    */ 
/*    */   public XHRuntimeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public XHRuntimeException(int code)
/*    */   {
/* 19 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public XHRuntimeException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ 
/*    */   public XHRuntimeException(Throwable cause)
/*    */   {
/* 33 */     super(cause);
/*    */   }
/*    */ 
/*    */   public XHRuntimeException(String message, Throwable cause)
/*    */   {
/* 41 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public int getCode() {
/* 45 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(int code) {
/* 49 */     this.code = code;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.exception.XHRuntimeException
 * JD-Core Version:    0.6.2
 */