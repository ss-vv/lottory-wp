/*    */ package com.xhcms.exception;
/*    */ 
/*    */ public class XHException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3842107227760452305L;
/*    */ 
/*    */   public XHException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public XHException(String message)
/*    */   {
/* 29 */     super(message);
/*    */   }
/*    */ 
/*    */   public XHException(Throwable cause)
/*    */   {
/* 37 */     super(cause);
/*    */   }
/*    */ 
/*    */   public XHException(String message, Throwable cause)
/*    */   {
/* 46 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.exception.XHException
 * JD-Core Version:    0.6.2
 */