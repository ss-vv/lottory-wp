/*    */ package com.xhcms.exception;
/*    */ 
/*    */ public class DataAccessException extends XHRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 3638025708978033057L;
/*    */ 
/*    */   public DataAccessException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DataAccessException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ 
/*    */   public DataAccessException(Throwable cause)
/*    */   {
/* 34 */     super(cause);
/*    */   }
/*    */ 
/*    */   public DataAccessException(String message, Throwable cause)
/*    */   {
/* 43 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-lang\0.0.1-SNAPSHOT\xhcms-commons-lang-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.exception.DataAccessException
 * JD-Core Version:    0.6.2
 */