package com.xhcms.commons.service;

import com.xhcms.exception.XHException;

public abstract interface TransactionService
{
  public abstract void execute(TransactionTask paramTransactionTask)
    throws XHException;
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-persist\0.0.1-SNAPSHOT\xhcms-commons-persist-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.service.TransactionService
 * JD-Core Version:    0.6.2
 */