/*    */ package com.xhcms.commons.service;
/*    */ 
/*    */ import com.xhcms.exception.XHException;
/*    */ import org.springframework.transaction.annotation.Transactional;
/*    */ 
/*    */ public class TransactionServiceSupport
/*    */   implements TransactionService
/*    */ {
/*    */   @Transactional
/*    */   public void execute(TransactionTask task)
/*    */     throws XHException
/*    */   {
/* 13 */     task.run();
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-persist\0.0.1-SNAPSHOT\xhcms-commons-persist-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.service.TransactionServiceSupport
 * JD-Core Version:    0.6.2
 */