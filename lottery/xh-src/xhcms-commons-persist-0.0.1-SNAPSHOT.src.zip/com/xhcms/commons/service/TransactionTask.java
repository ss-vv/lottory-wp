package com.xhcms.commons.service;

import com.xhcms.exception.XHException;

public abstract interface TransactionTask
{
  public abstract void run()
    throws XHException;
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-persist\0.0.1-SNAPSHOT\xhcms-commons-persist-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.service.TransactionTask
 * JD-Core Version:    0.6.2
 */