package com.xhcms.commons.persist;

import java.io.Serializable;
import java.util.List;

public abstract interface Dao<T> extends GenericDao
{
  public abstract T get(Serializable paramSerializable);

  public abstract void deleteById(Serializable paramSerializable);

  public abstract List<T> list();
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-persist\0.0.1-SNAPSHOT\xhcms-commons-persist-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.persist.Dao
 * JD-Core Version:    0.6.2
 */