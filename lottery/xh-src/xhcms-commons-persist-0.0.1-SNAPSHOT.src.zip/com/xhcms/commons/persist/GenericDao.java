package com.xhcms.commons.persist;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.Clob;

public abstract interface GenericDao extends Serializable
{
  public abstract void save(Object paramObject);

  public abstract void delete(Object paramObject);

  public abstract void update(Object paramObject);

  public abstract void saveOrUpdate(Object paramObject);

  public abstract void refresh(Object paramObject);

  public abstract Clob createClob(String paramString);

  public abstract Blob createBlob(byte[] paramArrayOfByte);
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-persist\0.0.1-SNAPSHOT\xhcms-commons-persist-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.persist.GenericDao
 * JD-Core Version:    0.6.2
 */