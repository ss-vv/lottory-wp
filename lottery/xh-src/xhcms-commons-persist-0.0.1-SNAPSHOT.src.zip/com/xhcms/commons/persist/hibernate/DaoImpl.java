/*    */ package com.xhcms.commons.persist.hibernate;
/*    */ 
/*    */ import com.xhcms.commons.lang.Paging;
/*    */ import com.xhcms.commons.persist.Dao;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.hibernate.Criteria;
/*    */ 
/*    */ public class DaoImpl<T> extends GenericDaoImpl
/*    */   implements Dao<T>
/*    */ {
/*    */   private static final long serialVersionUID = 3362415966471351147L;
/*    */   protected Class<T> entityClass;
/*    */ 
/*    */   /** @deprecated */
/*    */   protected DaoImpl()
/*    */   {
/*    */   }
/*    */ 
/*    */   protected DaoImpl(Class<T> c)
/*    */   {
/* 39 */     this.entityClass = c;
/*    */   }
/*    */ 
/*    */   public T get(Serializable id)
/*    */   {
/* 48 */     return get(this.entityClass, id);
/*    */   }
/*    */ 
/*    */   public void deleteById(Serializable id)
/*    */   {
/* 57 */     deleteById(this.entityClass, id);
/*    */   }
/*    */ 
/*    */   protected Criteria createCriteria() {
/* 61 */     return createCriteria(this.entityClass);
/*    */   }
/*    */ 
/*    */   protected GenericDaoImpl.TopQuery<T> topQuery(int maxResults) {
/* 65 */     return topQuery(maxResults, this.entityClass, null);
/*    */   }
/*    */ 
/*    */   protected GenericDaoImpl.TopQuery<T> topQuery(int maxResults, String cacheRegion) {
/* 69 */     return topQuery(maxResults, this.entityClass, cacheRegion);
/*    */   }
/*    */ 
/*    */   protected GenericDaoImpl.PagingQuery<T> pagingQuery(Paging paging) {
/* 73 */     return pagingQuery(paging, this.entityClass, null);
/*    */   }
/*    */ 
/*    */   protected GenericDaoImpl.PagingQuery<T> pagingQuery(Paging paging, String cacheRegion) {
/* 77 */     return pagingQuery(paging, this.entityClass, cacheRegion);
/*    */   }
/*    */ 
/*    */   public List<T> list()
/*    */   {
/* 83 */     return createCriteria().list();
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-persist\0.0.1-SNAPSHOT\xhcms-commons-persist-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.persist.hibernate.DaoImpl
 * JD-Core Version:    0.6.2
 */