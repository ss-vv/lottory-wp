/*     */ package com.xhcms.commons.persist.hibernate;
/*     */ 
/*     */ import com.xhcms.commons.lang.Paging;
/*     */ import com.xhcms.commons.persist.GenericDao;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.LobHelper;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.criterion.Criterion;
/*     */ import org.hibernate.criterion.Order;
/*     */ import org.hibernate.criterion.Projections;
/*     */ 
/*     */ public class GenericDaoImpl
/*     */   implements GenericDao
/*     */ {
/*     */   private static final long serialVersionUID = -2949117701796547684L;
/*     */   protected SessionFactory sessionFactory;
/*     */ 
/*     */   public SessionFactory getSessionFactory()
/*     */   {
/*  32 */     return this.sessionFactory;
/*     */   }
/*     */ 
/*     */   public void setSessionFactory(SessionFactory sessionFactory) {
/*  36 */     this.sessionFactory = sessionFactory;
/*     */   }
/*     */ 
/*     */   public void save(Object obj)
/*     */   {
/*  41 */     session().save(obj).hashCode();
/*     */   }
/*     */ 
/*     */   public void delete(Object obj)
/*     */   {
/*  46 */     session().delete(obj);
/*     */   }
/*     */ 
/*     */   public void update(Object obj)
/*     */   {
/*  51 */     session().update(obj);
/*     */   }
/*     */ 
/*     */   public void saveOrUpdate(Object obj)
/*     */   {
/*  56 */     session().saveOrUpdate(obj);
/*     */   }
/*     */ 
/*     */   public void refresh(Object obj)
/*     */   {
/*  61 */     session().refresh(obj);
/*     */   }
/*     */ 
/*     */   protected <E> E get(Class<E> clazz, Serializable id)
/*     */   {
/*  66 */     return session().get(clazz, id);
/*     */   }
/*     */ 
/*     */   protected void deleteById(Class<?> clazz, Serializable id) {
/*  70 */     Session s = session();
/*  71 */     Object obj = s.get(clazz, id);
/*  72 */     if (obj != null)
/*  73 */       s.delete(obj);
/*     */   }
/*     */ 
/*     */   protected void enableFilter(String name)
/*     */   {
/*  81 */     session().enableFilter(name);
/*     */   }
/*     */ 
/*     */   protected Session session()
/*     */   {
/*  89 */     return this.sessionFactory.getCurrentSession();
/*     */   }
/*     */ 
/*     */   protected Query createQuery(String hql)
/*     */   {
/*  98 */     return createQuery(hql, true, null);
/*     */   }
/*     */ 
/*     */   protected Query createQuery(String hql, boolean cacheable)
/*     */   {
/* 108 */     return createQuery(hql, cacheable, null);
/*     */   }
/*     */ 
/*     */   protected Query createQuery(String hql, boolean cacheable, String cacheRegion)
/*     */   {
/* 119 */     Query q = session().createQuery(hql).setCacheable(true);
/* 120 */     if ((cacheable) && (cacheRegion != null)) {
/* 121 */       q.setCacheRegion(cacheRegion);
/*     */     }
/* 123 */     return q;
/*     */   }
/*     */ 
/*     */   protected <E> TopQuery<E> topQuery(int maxResults, Class<E> clazz)
/*     */   {
/* 132 */     return new TopQuery(maxResults, clazz, null);
/*     */   }
/*     */ 
/*     */   protected <E> TopQuery<E> topQuery(int maxResults, Class<E> clazz, String cacheRegion)
/*     */   {
/* 141 */     return new TopQuery(maxResults, clazz, cacheRegion);
/*     */   }
/*     */ 
/*     */   protected <E> PagingQuery<E> pagingQuery(Paging paging, Class<E> clazz)
/*     */   {
/* 150 */     return new PagingQuery(paging, clazz, null);
/*     */   }
/*     */ 
/*     */   protected <E> PagingQuery<E> pagingQuery(Paging paging, Class<E> clazz, String cacheRegion)
/*     */   {
/* 160 */     return new PagingQuery(paging, clazz, cacheRegion);
/*     */   }
/*     */ 
/*     */   protected SQLQuery createSQLQuery(String sql)
/*     */   {
/* 169 */     return session().createSQLQuery(sql);
/*     */   }
/*     */ 
/*     */   protected Criteria createCriteria(Class<?> clazz)
/*     */   {
/* 178 */     return session().createCriteria(clazz).setCacheable(true);
/*     */   }
/*     */ 
/*     */   public Blob createBlob(byte[] bytes)
/*     */   {
/* 183 */     return session().getLobHelper().createBlob(bytes);
/*     */   }
/*     */ 
/*     */   public Clob createClob(String longText)
/*     */   {
/* 188 */     return session().getLobHelper().createClob(longText);
/*     */   }
/*     */ 
/*     */   private class Alias
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 5152383719243132307L;
/*     */     private String field;
/*     */     private String alias;
/*     */ 
/*     */     public Alias(String field, String alias)
/*     */     {
/* 328 */       this.field = field;
/* 329 */       this.alias = alias;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class PagingQuery<T> extends GenericDaoImpl.TopQuery<T>
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 397003060855915658L;
/*     */     Paging paging;
/*     */ 
/*     */     public PagingQuery(Class<T> paging, String clazz)
/*     */     {
/* 287 */       super(paging.getMaxResults(), clazz, cacheRegion);
/* 288 */       this.paging = paging;
/*     */     }
/*     */ 
/*     */     public List<T> list()
/*     */     {
/* 295 */       boolean query = true;
/*     */ 
/* 297 */       if (this.paging.isCount()) {
/* 298 */         int totalCount = ((Number)criteria(false).setProjection(Projections.rowCount()).uniqueResult()).intValue();
/* 299 */         this.paging.setTotalCount(totalCount);
/* 300 */         if (totalCount <= this.paging.getFirstResult()) {
/* 301 */           query = false;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 306 */       List results = Collections.EMPTY_LIST;
/* 307 */       if (query) {
/* 308 */         Criteria c = criteria(true).setFirstResult(this.paging.getFirstResult()).setMaxResults(this.paging.getMaxResults());
/* 309 */         results = c.list();
/*     */       }
/*     */ 
/* 312 */       this.paging.setResults(results);
/*     */ 
/* 314 */       return results;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class TopQuery<T>
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 8331182441328915375L;
/*     */     String cacheRegion;
/*     */     Class<T> clazz;
/* 200 */     List<Criterion> criterions = null;
/*     */ 
/* 202 */     List<Order> orders = null;
/*     */ 
/* 204 */     List<GenericDaoImpl.Alias> aliases = null;
/*     */     int maxResults;
/*     */ 
/*     */     public TopQuery(Class<T> maxResults, String clazz)
/*     */     {
/* 209 */       this.maxResults = maxResults;
/* 210 */       this.clazz = clazz;
/* 211 */       this.cacheRegion = cacheRegion;
/*     */     }
/*     */ 
/*     */     public TopQuery<T> add(Criterion c) {
/* 215 */       if (this.criterions == null) {
/* 216 */         this.criterions = new LinkedList();
/*     */       }
/* 218 */       this.criterions.add(c);
/* 219 */       return this;
/*     */     }
/*     */ 
/*     */     public TopQuery<T> asc(String field) {
/* 223 */       return add(Order.asc(field));
/*     */     }
/*     */ 
/*     */     public TopQuery<T> desc(String field) {
/* 227 */       return add(Order.desc(field));
/*     */     }
/*     */ 
/*     */     public TopQuery<T> alias(String field, String alias) {
/* 231 */       if (this.aliases == null) {
/* 232 */         this.aliases = new LinkedList();
/*     */       }
/* 234 */       this.aliases.add(new GenericDaoImpl.Alias(GenericDaoImpl.this, field, alias));
/* 235 */       return this;
/*     */     }
/*     */ 
/*     */     public List<T> list()
/*     */     {
/* 240 */       Criteria c = criteria(true);
/* 241 */       if (this.maxResults > 0) {
/* 242 */         c.setMaxResults(this.maxResults);
/*     */       }
/* 244 */       return c.list();
/*     */     }
/*     */ 
/*     */     protected Criteria criteria(boolean sortable) {
/* 248 */       Criteria c = GenericDaoImpl.this.createCriteria(this.clazz);
/* 249 */       if (this.criterions != null) {
/* 250 */         if (this.aliases != null) {
/* 251 */           for (GenericDaoImpl.Alias a : this.aliases) {
/* 252 */             c.createAlias(a.field, a.alias);
/*     */           }
/*     */         }
/* 255 */         for (Criterion ctn : this.criterions) {
/* 256 */           c.add(ctn);
/*     */         }
/*     */       }
/* 259 */       if (this.cacheRegion != null) {
/* 260 */         c.setCacheRegion(this.cacheRegion);
/*     */       }
/*     */ 
/* 263 */       if ((sortable) && (this.orders != null)) {
/* 264 */         for (Order o : this.orders) {
/* 265 */           c.addOrder(o);
/*     */         }
/*     */       }
/*     */ 
/* 269 */       return c;
/*     */     }
/*     */ 
/*     */     private TopQuery<T> add(Order o) {
/* 273 */       if (this.orders == null) {
/* 274 */         this.orders = new LinkedList();
/*     */       }
/* 276 */       this.orders.add(o);
/* 277 */       return this;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-persist\0.0.1-SNAPSHOT\xhcms-commons-persist-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.persist.hibernate.GenericDaoImpl
 * JD-Core Version:    0.6.2
 */