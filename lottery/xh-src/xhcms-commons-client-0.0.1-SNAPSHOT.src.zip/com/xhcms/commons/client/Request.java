package com.xhcms.commons.client;

import java.util.Map;

public abstract interface Request
{
  public abstract void setMethod(String paramString);

  public abstract void setApi(String paramString);

  public abstract void addParameters(Map<String, Object> paramMap);

  public abstract void addParameter(String paramString, Object paramObject);

  public abstract void addClass(String paramString, Class<?> paramClass);
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.Request
 * JD-Core Version:    0.6.2
 */