package com.xhcms.commons.client;

public abstract interface Response
{
  public abstract Object getData();

  public abstract int getCode();

  public abstract boolean isSuccess();
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.Response
 * JD-Core Version:    0.6.2
 */