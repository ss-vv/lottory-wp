/*    */ package com.xhcms.commons.client.http;
/*    */ 
/*    */ import com.xhcms.commons.client.Request;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class HttpRequest
/*    */   implements Request
/*    */ {
/*    */   private String method;
/*    */   private String api;
/* 14 */   private Map<String, Object> params = new HashMap();
/*    */   private Map<String, Class<?>> classMap;
/*    */ 
/*    */   public void setMethod(String method)
/*    */   {
/* 20 */     this.method = method;
/*    */   }
/*    */ 
/*    */   public void setApi(String api)
/*    */   {
/* 25 */     this.api = api;
/*    */   }
/*    */ 
/*    */   public void addParameters(Map<String, Object> params)
/*    */   {
/* 30 */     this.params.putAll(params);
/*    */   }
/*    */ 
/*    */   public void addParameter(String name, Object value)
/*    */   {
/* 35 */     this.params.put(name, value);
/*    */   }
/*    */ 
/*    */   public void addClass(String name, Class<?> clazz)
/*    */   {
/* 40 */     if (this.classMap == null) {
/* 41 */       this.classMap = new HashMap();
/*    */     }
/* 43 */     this.classMap.put(name, clazz);
/*    */   }
/*    */ 
/*    */   protected String getApi() {
/* 47 */     return this.api;
/*    */   }
/*    */ 
/*    */   protected String getMethod() {
/* 51 */     return this.method;
/*    */   }
/*    */ 
/*    */   protected Map<String, Object> getParameters() {
/* 55 */     return this.params;
/*    */   }
/*    */ 
/*    */   public Map<String, Class<?>> getClassMap() {
/* 59 */     return this.classMap;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.http.HttpRequest
 * JD-Core Version:    0.6.2
 */