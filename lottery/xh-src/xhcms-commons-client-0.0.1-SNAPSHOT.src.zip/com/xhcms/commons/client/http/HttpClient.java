/*     */ package com.xhcms.commons.client.http;
/*     */ 
/*     */ import com.xhcms.commons.client.Client;
/*     */ import com.xhcms.commons.client.ClientContext;
/*     */ import com.xhcms.commons.client.Request;
/*     */ import com.xhcms.commons.client.Response;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.http.NameValuePair;
/*     */ import org.apache.http.client.ClientProtocolException;
/*     */ import org.apache.http.client.ResponseHandler;
/*     */ import org.apache.http.client.entity.UrlEncodedFormEntity;
/*     */ import org.apache.http.client.methods.HttpGet;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpRequestBase;
/*     */ import org.apache.http.client.utils.URLEncodedUtils;
/*     */ import org.apache.http.conn.ClientConnectionManager;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.message.BasicNameValuePair;
/*     */ import org.apache.http.util.EntityUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class HttpClient
/*     */   implements Client
/*     */ {
/*  43 */   private static final Logger log = LoggerFactory.getLogger(HttpClient.class);
/*     */   private ClientContext clientContext;
/*     */ 
/*     */   public Response send(Request request)
/*     */   {
/*  49 */     HttpRequest req = (HttpRequest)request;
/*     */ 
/*  51 */     req.addParameter("__version", this.clientContext.getVersion());
/*  52 */     req.addParameter("__token", this.clientContext.getToken());
/*  53 */     req.addParameter("__secure", this.clientContext.getSecure());
/*     */ 
/*  55 */     String url = this.clientContext.lookup(req.getApi());
/*  56 */     if (url == null) {
/*  57 */       throw new IllegalArgumentException("Not found url for api: " + req.getApi());
/*     */     }
/*     */ 
/*  60 */     String json = null;
/*  61 */     if ("get".equals(req.getMethod()))
/*  62 */       json = get(url, req.getParameters());
/*  63 */     else if ("post".equals(req.getMethod()))
/*  64 */       json = post(url, req.getParameters());
/*     */     else {
/*  66 */       throw new UnsupportedOperationException("Only support method: post,get.");
/*     */     }
/*     */ 
/*  69 */     HttpResponse resp = (HttpResponse)JsonUtil.parse(json, HttpResponse.class, req.getClassMap());
/*  70 */     if (resp == null) {
/*  71 */       resp = new HttpResponse();
/*  72 */       resp.setCode(500);
/*     */     }
/*  74 */     return resp;
/*     */   }
/*     */ 
/*     */   public Request createGetRequest(String api)
/*     */   {
/*  83 */     HttpRequest req = new HttpRequest();
/*  84 */     req.setMethod("get");
/*  85 */     req.setApi(api);
/*     */ 
/*  87 */     return req;
/*     */   }
/*     */ 
/*     */   public Request createPostRequest(String api)
/*     */   {
/*  96 */     HttpRequest req = new HttpRequest();
/*  97 */     req.setMethod("post");
/*  98 */     req.setApi(api);
/*     */ 
/* 100 */     return req;
/*     */   }
/*     */ 
/*     */   public void setClientContext(ClientContext clientContext)
/*     */   {
/* 108 */     this.clientContext = clientContext;
/*     */   }
/*     */ 
/*     */   private List<NameValuePair> wrapParams(Map<String, Object> params)
/*     */   {
/* 113 */     if ((params == null) || (params.size() == 0)) {
/* 114 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */ 
/* 117 */     List pairs = new ArrayList(params.size());
/*     */ 
/* 119 */     for (String key : params.keySet()) {
/* 120 */       Object value = params.get(key);
/*     */ 
/* 123 */       if ((value instanceof Collection))
/* 124 */         for (Iterator localIterator2 = ((Collection)value).iterator(); localIterator2.hasNext(); ) { Object v = localIterator2.next();
/* 125 */           pairs.add(new BasicNameValuePair(key, v.toString()));
/*     */         }
/*     */       else {
/* 128 */         pairs.add(new BasicNameValuePair(key, value.toString()));
/*     */       }
/*     */     }
/*     */ 
/* 132 */     return pairs;
/*     */   }
/*     */ 
/*     */   private String get(String url, Map<String, Object> params) {
/* 136 */     String queryString = URLEncodedUtils.format(wrapParams(params), "UTF-8");
/* 137 */     HttpGet req = new HttpGet(wrapUrl(url, queryString));
/* 138 */     return execute(req);
/*     */   }
/*     */ 
/*     */   private String post(String url, Map<String, Object> params) {
/* 142 */     String responseBody = null;
/*     */ 
/* 144 */     HttpPost req = new HttpPost(url);
/*     */     try {
/* 146 */       UrlEncodedFormEntity entity = new UrlEncodedFormEntity(wrapParams(params), "UTF-8");
/* 147 */       req.setEntity(entity);
/* 148 */       responseBody = execute(req);
/*     */     } catch (UnsupportedEncodingException e) {
/* 150 */       log.warn(e.getMessage());
/*     */     }
/*     */ 
/* 153 */     return responseBody;
/*     */   }
/*     */ 
/*     */   private String execute(HttpRequestBase request) {
/* 157 */     DefaultHttpClient client = new DefaultHttpClient();
/*     */ 
/* 159 */     String responseBody = null;
/*     */     try {
/* 161 */       responseBody = (String)client.execute(request, new ResponseHandler()
/*     */       {
/*     */         public String handleResponse(org.apache.http.HttpResponse response) throws ClientProtocolException, IOException {
/* 164 */           String chaset = EntityUtils.getContentCharSet(response.getEntity());
/*     */ 
/* 166 */           if (chaset == null) {
/* 167 */             chaset = "UTF-8";
/*     */           }
/* 169 */           return EntityUtils.toString(response.getEntity(), chaset);
/*     */         } } );
/*     */     }
/*     */     catch (ClientProtocolException e) {
/* 173 */       log.warn(e.getMessage());
/*     */     } catch (IOException e) {
/* 175 */       log.warn(e.getMessage());
/*     */     } finally {
/* 177 */       if (request != null) {
/* 178 */         request.abort();
/*     */       }
/* 180 */       if (client != null) {
/* 181 */         client.getConnectionManager().shutdown();
/*     */       }
/*     */     }
/* 184 */     return responseBody;
/*     */   }
/*     */ 
/*     */   private String wrapUrl(String url, String queryString) {
/* 188 */     return 256 + url + (
/* 189 */       url.lastIndexOf('?') == -1 ? "?" : "&") + 
/* 190 */       queryString;
/*     */   }
/*     */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.http.HttpClient
 * JD-Core Version:    0.6.2
 */