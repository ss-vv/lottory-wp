/*    */ package com.xhcms.commons.client.http;
/*    */ 
/*    */ import java.util.Map;
/*    */ import net.sf.ezmorph.MorpherRegistry;
/*    */ import net.sf.json.JSONObject;
/*    */ import net.sf.json.util.JSONUtils;
/*    */ 
/*    */ public class JsonUtil
/*    */ {
/*    */   static
/*    */   {
/* 20 */     JSONUtils.getMorpherRegistry().registerMorpher(new StringToDateMorpher());
/*    */   }
/*    */ 
/*    */   public static <T> T parse(Object json, Class<T> beanType, Map<String, Class<?>> classMap)
/*    */   {
/* 36 */     JSONObject obj = null;
/* 37 */     if ((json instanceof JSONObject))
/* 38 */       obj = (JSONObject)json;
/*    */     else {
/* 40 */       obj = JSONObject.fromObject(json);
/*    */     }
/* 42 */     return JSONObject.toBean(obj, beanType, classMap);
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.http.JsonUtil
 * JD-Core Version:    0.6.2
 */