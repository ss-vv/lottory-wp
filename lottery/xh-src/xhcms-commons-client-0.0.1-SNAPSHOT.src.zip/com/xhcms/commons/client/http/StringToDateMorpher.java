/*    */ package com.xhcms.commons.client.http;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import net.sf.ezmorph.object.AbstractObjectMorpher;
/*    */ 
/*    */ public class StringToDateMorpher extends AbstractObjectMorpher
/*    */ {
/*    */   private static final String PATTERN = "yyyy-MM-dd'T'HH:mm:ss";
/* 13 */   private static final int LENGTH = "yyyy-MM-dd'T'HH:mm:ss".length() - 2;
/*    */ 
/*    */   public Object morph(Object value)
/*    */   {
/* 17 */     if ((value instanceof String)) {
/* 18 */       return toDate((String)value);
/*    */     }
/* 20 */     return null;
/*    */   }
/*    */ 
/*    */   public Class<?> morphsTo()
/*    */   {
/* 25 */     return Date.class;
/*    */   }
/*    */ 
/*    */   private Date toDate(String s) {
/* 29 */     if (s.trim().length() == LENGTH)
/*    */       try {
/* 31 */         return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(s);
/*    */       }
/*    */       catch (ParseException localParseException) {
/*    */       }
/* 35 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.http.StringToDateMorpher
 * JD-Core Version:    0.6.2
 */