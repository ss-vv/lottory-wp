/*    */ package com.xhcms.commons.client.http;
/*    */ 
/*    */ import com.xhcms.commons.client.Response;
/*    */ 
/*    */ public class HttpResponse
/*    */   implements Response
/*    */ {
/*    */   private int code;
/*    */   private Object data;
/*    */ 
/*    */   public Object getData()
/*    */   {
/* 23 */     return this.data;
/*    */   }
/*    */ 
/*    */   public int getCode()
/*    */   {
/* 28 */     return this.code;
/*    */   }
/*    */ 
/*    */   public boolean isSuccess()
/*    */   {
/* 33 */     return 200 == this.code;
/*    */   }
/*    */ 
/*    */   public void setData(Object data)
/*    */   {
/* 41 */     this.data = data;
/*    */   }
/*    */ 
/*    */   public void setCode(int code) {
/* 45 */     this.code = code;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.http.HttpResponse
 * JD-Core Version:    0.6.2
 */