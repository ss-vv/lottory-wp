/*    */ package com.xhcms.commons.client;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ClientContext
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -2183390604198677891L;
/*    */   private String version;
/*    */   private String token;
/*    */   private String secure;
/*    */   private String server;
/* 33 */   private Map<String, String> uris = new HashMap();
/*    */ 
/*    */   public String lookup(String api)
/*    */   {
/* 41 */     String uri = (String)this.uris.get(api);
/* 42 */     if (uri == null) {
/* 43 */       return null;
/*    */     }
/*    */ 
/* 46 */     if ('/' == uri.charAt(0)) {
/* 47 */       return this.server + uri;
/*    */     }
/* 49 */     return this.server + "/" + uri;
/*    */   }
/*    */ 
/*    */   public String getVersion() {
/* 53 */     return this.version;
/*    */   }
/*    */ 
/*    */   public void setVersion(String version) {
/* 57 */     this.version = version;
/*    */   }
/*    */ 
/*    */   public String getToken() {
/* 61 */     return this.token;
/*    */   }
/*    */ 
/*    */   public void setToken(String token) {
/* 65 */     this.token = token;
/*    */   }
/*    */ 
/*    */   public String getSecure() {
/* 69 */     return this.secure;
/*    */   }
/*    */ 
/*    */   public void setSecure(String secure) {
/* 73 */     this.secure = secure;
/*    */   }
/*    */ 
/*    */   public String getServer() {
/* 77 */     return this.server;
/*    */   }
/*    */ 
/*    */   public void setServer(String server) {
/* 81 */     this.server = server;
/*    */   }
/*    */ 
/*    */   public Map<String, String> getUris() {
/* 85 */     return this.uris;
/*    */   }
/*    */ 
/*    */   public void setUris(Map<String, String> uris) {
/* 89 */     this.uris = uris;
/*    */   }
/*    */ }

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.ClientContext
 * JD-Core Version:    0.6.2
 */