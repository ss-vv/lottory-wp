package com.xhcms.commons.client;

public abstract interface Client
{
  public abstract Response send(Request paramRequest);
}

/* Location:           E:\Java\m2_repo\com\xhcms\commons\xhcms-commons-client\0.0.1-SNAPSHOT\xhcms-commons-client-0.0.1-SNAPSHOT.jar
 * Qualified Name:     com.xhcms.commons.client.Client
 * JD-Core Version:    0.6.2
 */